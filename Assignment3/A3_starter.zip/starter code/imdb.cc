using namespace std;
#include <sys/types.h>
#include <sys/stat.h>
//#include <sys/mman.h>
#include <fcntl.h>
//#include <unistd.h>
#include "imdb.h"
#include <stdlib.h>

const char *const imdb::kActorFileName = "actordata";
const char *const imdb::kMovieFileName = "moviedata";

imdb::imdb(const string& directory)
{
  const string actorFileName = directory + "\\" + kActorFileName;
  const string movieFileName = directory + "\\" + kMovieFileName;
  
  actorFile = acquireFileMap(actorFileName, actorInfo);
  movieFile = acquireFileMap(movieFileName, movieInfo);
}

bool imdb::good() const
{
  return !( (actorInfo.fd == -1) || 
	    (movieInfo.fd == -1) ); 
}

// you should be implementing these two methods right here... 
bool imdb::getFilm(size_t idx, vector<string>& players ) const { return false; }
bool imdb::getPlayer(size_t idx, vector<film>& films) const { return false; }

imdb::~imdb()
{
  releaseFileMap(actorInfo);
  releaseFileMap(movieInfo);
}




const void *imdb::acquireFileMap(const string& fileName, struct fileInfo& info)
{
	struct stat stats;
	stat(fileName.c_str(), &stats);

	info.fileSize = stats.st_size;
	FILE *fp = fopen(fileName.c_str(), "rb");

	info.fd = (int)fp;
	info.fileMap = (void *)malloc(info.fileSize);

	int ss = 0;
	if (!fp) {
		printf("error: could not open image file %s\n", fileName.c_str());
	}
	ss = fread((void *)info.fileMap, 1, stats.st_size, fp);


	fclose((FILE *)info.fd);

	return info.fileMap;

		//mmap(0, info.fileSize, PROT_READ, MAP_SHARED, info.fd, 0);
}

void imdb::releaseFileMap(struct fileInfo& info)
{
	if (info.fileMap != NULL)
		free((char * )info.fileMap);

}