//
//  encryptor.cpp
//  Assignment4
//
//  Created by ARDA on 4/8/18.
//  Copyright © 2018 ARDA. All rights reserved.
//

#include <fstream>
#include <iostream>
#include <string>

static std::string str_xor(const std::string &data, const std::string &key) {
    std::string result(data.size(), '\0');
    
    for (std::size_t i = 0; i < data.size(); i++) {
        result[i] = data[i] ^ key[i % key.size()];
    }
    return result;
}

int main(int argc, char **argv) {
    if (argc != 3) {
        std::cerr << "usage: xor <datafile> <keyfile>\n";
        return 1;
    }
    
    std::ifstream data_in(argv[1]);
    std::string data(
                     (std::istreambuf_iterator<char>(data_in)),
                     (std::istreambuf_iterator<char>()));
    data_in.close();

    std::ifstream key_in(argv[2]);
    std::string key(
                    (std::istreambuf_iterator<char>(key_in)),
                    (std::istreambuf_iterator<char>()));
    key_in.close();
    
    std::string result = str_xor(data, key);
    
    std::ofstream data_out(argv[1]);
    data_out << result;
    data_out.close();
    
    return 0;
}
