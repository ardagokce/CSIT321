//
//  main.cpp
//  Assignment4
//
//  Created by ARDA on 4/2/18.
//  Copyright © 2018 ARDA. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    //Problem 1
    signed short o = 32767;
    unsigned short j = 65535;
    short  a = 1025;
    char  b = 125;
    char c = a;
    short d = b;
    
    std::cout << o + 1 << std::endl;
    std::cout << j + 1 << std::endl;
    std::cout << c << std::endl;
    std::cout << d << std::endl;
    
    //Problem 2
    signed short shiftedl = o << 3;
    signed short shiftedr = o >> 3;
    unsigned short shiftedleft = j << 3;
    unsigned short shiftedright = j >> 3;
    
    std::cout << shiftedl << std::endl;
    std::cout << shiftedr << std::endl;
    std::cout << shiftedleft << std::endl;
    std::cout << shiftedright << std::endl;
    
    
    
    
    
}
